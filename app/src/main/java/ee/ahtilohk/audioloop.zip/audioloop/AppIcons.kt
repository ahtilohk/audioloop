package ee.ahtilohk.audioloop

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

object AppIcons {
    // Replacement for Icons.Default.School
    val School: ImageVector
        get() {
            if (_school != null) return _school!!
            _school = materialIcon(name = "School") {
                materialPath {
                    moveTo(12.0f, 3.0f)
                    lineTo(1.0f, 9.0f)
                    lineToRelative(4.0f, 2.18f)
                    verticalLineToRelative(6.0f)
                    lineTo(12.0f, 21.0f)
                    lineToRelative(7.0f, -3.82f)
                    verticalLineToRelative(-6.0f)
                    lineToRelative(2.0f, -1.09f)
                    lineTo(21.0f, 17.0f)
                    horizontalLineToRelative(2.0f)
                    verticalLineTo(9.0f)
                    lineTo(12.0f, 3.0f)
                    close()
                    moveTo(6.82f, 13.0f)
                    verticalLineToRelative(-1.46f)
                    lineToRelative(5.18f, 2.82f)
                    lineToRelative(5.18f, -2.82f)
                    verticalLineTo(13.0f)
                    lineTo(12.0f, 15.82f)
                    lineTo(6.82f, 13.0f)
                    close()
                }
            }
            return _school!!
        }
    private var _school: ImageVector? = null

    // Replacement for Icons.Default.Stop (Not in Core)
    val Stop: ImageVector
        get() {
            if (_stop != null) return _stop!!
            _stop = materialIcon(name = "Stop") {
                materialPath {
                    moveTo(6.0f, 6.0f)
                    horizontalLineToRelative(12.0f)
                    verticalLineToRelative(12.0f)
                    horizontalLineTo(6.0f)
                    close()
                }
            }
            return _stop!!
        }
    private var _stop: ImageVector? = null

    // Replacement for Icons.Default.GraphicEq
    val GraphicEq: ImageVector
        get() {
            if (_graphicEq != null) return _graphicEq!!
            _graphicEq = materialIcon(name = "GraphicEq") {
                // Simple 3-bar equalizer
                materialPath {
                    // Bar 1
                    moveTo(7.0f, 18.0f)
                    verticalLineTo(6.0f)
                    horizontalLineToRelative(-4.0f)
                    verticalLineToRelative(12.0f)
                    close()
                    // Bar 2
                    moveTo(13.0f, 20.0f)
                    verticalLineTo(4.0f)
                    horizontalLineToRelative(-4.0f)
                    verticalLineToRelative(16.0f)
                    close()
                    // Bar 3
                    moveTo(19.0f, 16.0f)
                    verticalLineTo(8.0f)
                    horizontalLineToRelative(-4.0f)
                    verticalLineToRelative(8.0f)
                    close()
                }
            }
            return _graphicEq!!
        }
    private var _graphicEq: ImageVector? = null

    // Replacement for Icons.Default.ContentCut
    val ContentCut: ImageVector
        get() {
            if (_contentCut != null) return _contentCut!!
            _contentCut = materialIcon(name = "ContentCut") {
                // Simplified "Scissors"
                materialPath {
                     // Circle Left 
                    moveTo(6.0f, 16.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(0.9f, 2.0f, 2.0f, 2.0f)
                    reflectiveCurveToRelative(2.0f, -0.9f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(-0.9f, -2.0f, -2.0f, -2.0f)
                    close()
                    // Circle Right
                    moveTo(18.0f, 16.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(0.9f, 2.0f, 2.0f, 2.0f)
                    reflectiveCurveToRelative(2.0f, -0.9f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(-0.9f, -2.0f, -2.0f, -2.0f)
                    close()
                    // Blades X
                    moveTo(9.64f, 7.64f)
                    lineTo(12.0f, 10.0f) // Center
                    lineToRelative(2.36f, -2.36f)
                    // ... This is getting complex to simulate cutout.
                    // Let's just draw two crossing lines
                    moveTo(6.0f, 8.0f) // Start blade 1 top left
                    lineTo(16.0f, 18.0f) // End blade 1 bottom right (near handle) but handle is circle
                    
                    // Actually, let's use a simpler path:
                    // Loops at bottom, lines crossing to top
                    
                    // Left Blade
                    moveTo(7.5f, 16.5f)
                    lineTo(16.0f, 5.0f)
                    horizontalLineToRelative(2.0f) // Tip
                    lineTo(10.0f, 16.0f)
                    
                    // Right Blade
                    moveTo(16.5f, 16.5f)
                    lineTo(8.0f, 5.0f)
                    horizontalLineToRelative(-2.0f) // Tip
                    lineTo(14.0f, 16.0f)
                }
            }
            return _contentCut!!
        }
    private var _contentCut: ImageVector? = null

    val OpenInNew: ImageVector
        get() {
            if (_openInNew != null) return _openInNew!!
            _openInNew = materialIcon(name = "OpenInNew") {
                materialPath {
                    moveTo(19.0f, 19.0f)
                    horizontalLineTo(5.0f)
                    verticalLineTo(5.0f)
                    horizontalLineToRelative(7.0f)
                    verticalLineTo(3.0f)
                    horizontalLineTo(5.0f)
                    curveToRelative(-1.11f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    verticalLineToRelative(14.0f)
                    curveToRelative(0.0f, 1.1f, 0.89f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(14.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    verticalLineToRelative(-7.0f)
                    horizontalLineToRelative(-2.0f)
                    verticalLineToRelative(7.0f)
                    close()
                    moveTo(14.0f, 3.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(3.59f)
                    lineToRelative(-9.83f, 9.83f)
                    lineToRelative(1.41f, 1.41f)
                    lineTo(19.0f, 6.41f)
                    verticalLineTo(10.0f)
                    horizontalLineToRelative(2.0f)
                    verticalLineTo(3.0f)
                    horizontalLineToRelative(-7.0f)
                    close()
                }
            }
            return _openInNew!!
        }
    private var _openInNew: ImageVector? = null

    // Replacement for Icons.AutoMirrored.Filled.ArrowBack
    val ArrowBack: ImageVector
        get() {
            if (_arrowBack != null) return _arrowBack!!
            _arrowBack = materialIcon(name = "ArrowBack") {
                materialPath {
                    moveTo(20.0f, 11.0f)
                    horizontalLineTo(7.83f)
                    lineToRelative(5.59f, -5.59f)
                    lineTo(12.0f, 4.0f)
                    lineToRelative(-8.0f, 8.0f)
                    lineToRelative(8.0f, 8.0f)
                    lineToRelative(1.41f, -1.41f)
                    lineTo(7.83f, 13.0f)
                    horizontalLineTo(20.0f)
                    verticalLineToRelative(-2.0f)
                    close()
                }
            }
            return _arrowBack!!
        }
    private var _arrowBack: ImageVector? = null

    // Replacement for Icons.AutoMirrored.Filled.ArrowForward
    val ArrowForward: ImageVector
        get() {
            if (_arrowForward != null) return _arrowForward!!
            _arrowForward = materialIcon(name = "ArrowForward") {
                materialPath {
                    moveTo(12.0f, 4.0f)
                    lineToRelative(-1.41f, 1.41f)
                    lineTo(16.17f, 11.0f)
                    horizontalLineTo(4.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(12.17f)
                    lineToRelative(-5.58f, 5.59f)
                    lineTo(12.0f, 20.0f)
                    lineToRelative(8.0f, -8.0f)
                    close()
                }
            }
            return _arrowForward!!
        }
    private var _arrowForward: ImageVector? = null

    // Replacement for Icons.Default.ArrowDownward
    val ArrowDownward: ImageVector
        get() {
            if (_arrowDownward != null) return _arrowDownward!!
            _arrowDownward = materialIcon(name = "ArrowDownward") {
                materialPath {
                    moveTo(20.0f, 12.0f)
                    lineToRelative(-1.41f, -1.41f)
                    lineTo(13.0f, 16.17f)
                    verticalLineTo(4.0f)
                    horizontalLineToRelative(-2.0f)
                    verticalLineToRelative(12.17f)
                    lineToRelative(-5.58f, -5.59f)
                    lineTo(4.0f, 12.0f)
                    lineToRelative(8.0f, 8.0f)
                    lineToRelative(8.0f, -8.0f)
                    close()
                }
            }
            return _arrowDownward!!
        }
    private var _arrowDownward: ImageVector? = null

    // Replacement for Icons.Default.Mic
    val Mic: ImageVector
        get() {
            if (_mic != null) return _mic!!
            _mic = materialIcon(name = "Mic") {
                materialPath {
                    moveTo(12.0f, 14.0f)
                    curveToRelative(1.66f, 0.0f, 3.0f, -1.34f, 3.0f, -3.0f)
                    verticalLineTo(5.0f)
                    curveToRelative(0.0f, -1.66f, -1.34f, -3.0f, -3.0f, -3.0f)
                    reflectiveCurveTo(9.0f, 3.34f, 9.0f, 5.0f)
                    verticalLineToRelative(6.0f)
                    curveTo(9.0f, 12.66f, 10.34f, 14.0f, 12.0f, 14.0f)
                    close()
                    moveTo(17.0f, 11.0f)
                    curveToRelative(0.0f, 2.76f, -2.24f, 5.0f, -5.0f, 5.0f)
                    reflectiveCurveToRelative(-5.0f, -2.24f, -5.0f, -5.0f)
                    horizontalLineTo(5.0f)
                    curveToRelative(0.0f, 3.53f, 2.61f, 6.43f, 6.0f, 6.92f)
                    verticalLineTo(21.0f)
                    horizontalLineToRelative(2.0f)
                    verticalLineToRelative(-3.08f)
                    curveToRelative(3.39f, -0.49f, 6.0f, -3.39f, 6.0f, -6.92f)
                    horizontalLineTo(17.0f)
                    close()
                }
            }
            return _mic!!
        }
    private var _mic: ImageVector? = null

    // Replacement for Icons.Default.Add
    val Add: ImageVector
        get() {
            if (_add != null) return _add!!
            _add = materialIcon(name = "Add") {
                materialPath {
                    moveTo(19.0f, 13.0f)
                    horizontalLineToRelative(-6.0f)
                    verticalLineToRelative(6.0f)
                    horizontalLineToRelative(-2.0f)
                    verticalLineToRelative(-6.0f)
                    horizontalLineTo(5.0f)
                    verticalLineToRelative(-2.0f)
                    horizontalLineToRelative(6.0f)
                    verticalLineTo(5.0f)
                    horizontalLineToRelative(2.0f)
                    verticalLineToRelative(6.0f)
                    horizontalLineToRelative(6.0f)
                    verticalLineTo(13.0f)
                    close()
                }
            }
            return _add!!
        }
    private var _add: ImageVector? = null

    // Replacement for Icons.Default.PlayArrow
    val PlayArrow: ImageVector
        get() {
            if (_playArrow != null) return _playArrow!!
            _playArrow = materialIcon(name = "PlayArrow") {
                materialPath {
                    moveTo(8.0f, 5.0f)
                    verticalLineToRelative(14.0f)
                    lineToRelative(11.0f, -7.0f)
                    close()
                }
            }
            return _playArrow!!
        }
    private var _playArrow: ImageVector? = null

    val Play: ImageVector
        get() = PlayArrow

    // Replacement for Icons.Default.Pause
    val Pause: ImageVector
        get() {
            if (_pause != null) return _pause!!
            _pause = materialIcon(name = "Pause") {
                materialPath {
                    moveTo(6.0f, 19.0f)
                    horizontalLineToRelative(4.0f)
                    verticalLineTo(5.0f)
                    horizontalLineTo(6.0f)
                    verticalLineToRelative(14.0f)
                    close()
                    moveTo(14.0f, 5.0f)
                    verticalLineToRelative(14.0f)
                    horizontalLineToRelative(4.0f)
                    verticalLineTo(5.0f)
                    horizontalLineToRelative(-4.0f)
                    close()
                }
            }
            return _pause!!
        }
    private var _pause: ImageVector? = null

    // Replacement for Icons.Default.MoreVert
    val MoreVert: ImageVector
        get() {
            if (_moreVert != null) return _moreVert!!
            _moreVert = materialIcon(name = "MoreVert") {
                materialPath {
                    moveTo(12.0f, 8.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(-0.9f, -2.0f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(-2.0f, 0.9f, -2.0f, 2.0f)
                    reflectiveCurveTo(11.1f, 8.0f, 12.0f, 8.0f)
                    close()
                    moveTo(12.0f, 10.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(0.9f, 2.0f, 2.0f, 2.0f)
                    reflectiveCurveToRelative(2.0f, -0.9f, 2.0f, -2.0f)
                    reflectiveCurveTo(13.1f, 10.0f, 12.0f, 10.0f)
                    close()
                    moveTo(12.0f, 16.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(0.9f, 2.0f, 2.0f, 2.0f)
                    reflectiveCurveToRelative(2.0f, -0.9f, 2.0f, -2.0f)
                    reflectiveCurveTo(13.1f, 16.0f, 12.0f, 16.0f)
                    close()
                }
            }
            return _moreVert!!
        }
    private var _moreVert: ImageVector? = null

    // Replacement for Icons.Default.Settings
    val Settings: ImageVector
        get() {
            if (_settings != null) return _settings!!
            _settings = materialIcon(name = "Settings") {
                materialPath {
                    moveTo(19.14f, 12.94f)
                    curveToRelative(0.04f, -0.3f, 0.06f, -0.61f, 0.06f, -0.94f)
                    curveToRelative(0.0f, -0.32f, -0.02f, -0.64f, -0.06f, -0.94f)
                    lineToRelative(2.03f, -1.58f)
                    curveToRelative(0.18f, -0.14f, 0.23f, -0.41f, 0.12f, -0.61f)
                    lineToRelative(-1.92f, -3.32f)
                    curveToRelative(-0.12f, -0.22f, -0.37f, -0.29f, -0.59f, -0.22f)
                    lineToRelative(-2.39f, 0.96f)
                    curveToRelative(-0.5f, -0.38f, -1.03f, -0.7f, -1.62f, -0.94f)
                    lineToRelative(-0.36f, -2.54f)
                    curveToRelative(-0.04f, -0.24f, -0.24f, -0.41f, -0.48f, -0.41f)
                    horizontalLineToRelative(-3.84f)
                    curveToRelative(-0.24f, 0.0f, -0.43f, 0.17f, -0.47f, 0.41f)
                    lineTo(9.25f, 4.35f)
                    curveToRelative(-0.59f, 0.24f, -1.13f, 0.57f, -1.62f, 0.94f)
                    lineTo(5.24f, 4.33f)
                    curveToRelative(-0.22f, -0.08f, -0.47f, 0.0f, -0.59f, 0.22f)
                    lineTo(2.73f, 7.87f)
                    curveToRelative(-0.11f, 0.21f, -0.06f, 0.47f, 0.12f, 0.61f)
                    lineToRelative(2.03f, 1.58f)
                    curveToRelative(-0.04f, 0.3f, -0.06f, 0.61f, -0.06f, 0.94f)
                    reflectiveCurveToRelative(0.02f, 0.64f, 0.06f, 0.94f)
                    lineToRelative(-2.03f, 1.58f)
                    curveToRelative(-0.18f, 0.14f, -0.23f, 0.41f, -0.12f, 0.61f)
                    lineToRelative(1.92f, 3.32f)
                    curveToRelative(0.12f, 0.22f, 0.37f, 0.29f, 0.59f, 0.22f)
                    lineToRelative(2.39f, -0.96f)
                    curveToRelative(0.5f, 0.38f, 1.03f, 0.7f, 1.62f, 0.94f)
                    lineToRelative(0.36f, 2.54f)
                    curveToRelative(0.05f, 0.24f, 0.24f, 0.41f, 0.48f, 0.41f)
                    horizontalLineToRelative(3.84f)
                    curveToRelative(0.24f, 0.0f, 0.44f, -0.17f, 0.47f, -0.41f)
                    lineToRelative(0.36f, -2.54f)
                    curveToRelative(0.59f, -0.24f, 1.13f, -0.56f, 1.62f, -0.94f)
                    lineToRelative(2.39f, 0.96f)
                    curveToRelative(0.22f, 0.08f, 0.47f, 0.0f, 0.59f, -0.22f)
                    lineToRelative(1.92f, -3.32f)
                    curveToRelative(0.11f, -0.22f, 0.05f, -0.47f, -0.12f, -0.61f)
                    lineToRelative(-2.01f, -1.58f)
                    close()
                    moveTo(12.0f, 15.6f)
                    curveToRelative(-1.98f, 0.0f, -3.6f, -1.62f, -3.6f, -3.6f)
                    reflectiveCurveToRelative(1.62f, -3.6f, 3.6f, -3.6f)
                    reflectiveCurveToRelative(3.6f, 1.62f, 3.6f, 3.6f)
                    reflectiveCurveToRelative(-1.62f, 3.6f, -3.6f, 3.6f)
                    close()
                }
            }
            return _settings!!
        }
    private var _settings: ImageVector? = null

    // Replacement for Icons.Default.Radio
    val Radio: ImageVector
        get() {
            if (_radio != null) return _radio!!
            _radio = materialIcon(name = "Radio") {
                materialPath(fillAlpha = 0.5f, strokeAlpha = 0.5f) {
                    moveTo(3.24f, 6.15f)
                    curveTo(2.51f, 6.43f, 2.0f, 7.17f, 2.0f, 8.0f)
                    verticalLineToRelative(12.0f)
                    curveToRelative(0.0f, 1.1f, 0.89f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(16.0f)
                    curveToRelative(1.11f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    verticalLineTo(8.0f)
                    curveToRelative(0.0f, -1.11f, -0.89f, -2.0f, -2.0f, -2.0f)
                    horizontalLineTo(8.3f)
                    lineToRelative(8.26f, -3.34f)
                    lineTo(15.88f, 1.0f)
                    lineTo(3.24f, 6.15f)
                    close()
                    moveTo(7.0f, 20.0f)
                    curveToRelative(-1.66f, 0.0f, -3.0f, -1.34f, -3.0f, -3.0f)
                    reflectiveCurveToRelative(1.34f, -3.0f, 3.0f, -3.0f)
                    reflectiveCurveToRelative(3.0f, 1.34f, 3.0f, 3.0f)
                    reflectiveCurveToRelative(-1.34f, 3.0f, -3.0f, 3.0f)
                    close()
                    moveTo(18.0f, 10.0f)
                    curveToRelative(-1.1f, 0.0f, -2.0f, -0.9f, -2.0f, -2.0f)
                    // Note: Simplified radio mostly
                }
            }
            return _radio!!
        }
    private var _radio: ImageVector? = null

    // Replacement for Icons.Default.Check
    val Check: ImageVector
        get() {
            if (_check != null) return _check!!
            _check = materialIcon(name = "Check") {
                materialPath {
                    moveTo(9.0f, 16.17f)
                    lineTo(4.83f, 12.0f)
                    lineToRelative(-1.42f, 1.41f)
                    lineTo(9.0f, 19.0f)
                    lineTo(21.0f, 7.0f)
                    lineToRelative(-1.41f, -1.41f)
                    close()
                }
            }
            return _check!!
        }
    private var _check: ImageVector? = null

    // Replacement for Icons.Default.KeyboardArrowDown (ChevronDown)
    val ChevronDown: ImageVector
        get() {
            if (_chevronDown != null) return _chevronDown!!
            _chevronDown = materialIcon(name = "ChevronDown") {
                materialPath {
                    moveTo(7.41f, 8.59f)
                    lineTo(12.0f, 13.17f)
                    lineToRelative(4.59f, -4.58f)
                    lineTo(18.0f, 10.0f)
                    lineToRelative(-6.0f, 6.0f)
                    lineToRelative(-6.0f, -6.0f)
                    close()
                }
            }
            return _chevronDown!!
        }
    private var _chevronDown: ImageVector? = null

    // Replacement for Icons.Default.KeyboardArrowUp (ChevronUp)
    val ChevronUp: ImageVector
        get() {
            if (_chevronUp != null) return _chevronUp!!
            _chevronUp = materialIcon(name = "ChevronUp") {
                materialPath {
                    moveTo(7.41f, 15.41f)
                    lineTo(12.0f, 10.83f)
                    lineToRelative(4.59f, 4.58f)
                    lineTo(18.0f, 14.0f)
                    lineToRelative(-6.0f, -6.0f)
                    lineToRelative(-6.0f, 6.0f)
                    close()
                }
            }
            return _chevronUp!!
        }
    private var _chevronUp: ImageVector? = null

   // Replacement for Icons.Default.DragIndicator (GripVertical)
    val GripVertical: ImageVector
        get() {
            if (_gripVertical != null) return _gripVertical!!
            _gripVertical = materialIcon(name = "GripVertical") {
                 materialPath {
                    moveTo(11.0f, 18.0f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(0.9f, -2.0f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(2.0f, 0.9f, 2.0f, 2.0f)
                    close()
                    moveTo(11.0f, 6.0f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(0.9f, -2.0f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(2.0f, 0.9f, 2.0f, 2.0f)
                    close()
                    moveTo(11.0f, 12.0f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(0.9f, -2.0f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(2.0f, 0.9f, 2.0f, 2.0f)
                    close()
                    moveTo(15.0f, 6.0f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(0.9f, -2.0f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(2.0f, 0.9f, 2.0f, 2.0f)
                    close()
                    moveTo(15.0f, 12.0f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(0.9f, -2.0f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(2.0f, 0.9f, 2.0f, 2.0f)
                    close()
                    moveTo(15.0f, 18.0f)
                    curveToRelative(0.0f, 1.1f, -0.9f, 2.0f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(-2.0f, -0.9f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(0.9f, -2.0f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(2.0f, 0.9f, 2.0f, 2.0f)
                    close()
                }
            }
            return _gripVertical!!
        }
    private var _gripVertical: ImageVector? = null

    // Search icon (magnifying glass)
    val Search: ImageVector
        get() {
            if (_search != null) return _search!!
            _search = materialIcon(name = "Search") {
                materialPath {
                    moveTo(15.5f, 14.0f)
                    horizontalLineToRelative(-0.79f)
                    lineToRelative(-0.28f, -0.27f)
                    curveTo(15.41f, 12.59f, 16.0f, 11.11f, 16.0f, 9.5f)
                    curveTo(16.0f, 5.91f, 13.09f, 3.0f, 9.5f, 3.0f)
                    reflectiveCurveTo(3.0f, 5.91f, 3.0f, 9.5f)
                    reflectiveCurveTo(5.91f, 16.0f, 9.5f, 16.0f)
                    curveToRelative(1.61f, 0.0f, 3.09f, -0.59f, 4.23f, -1.57f)
                    lineToRelative(0.27f, 0.28f)
                    verticalLineToRelative(0.79f)
                    lineToRelative(5.0f, 4.99f)
                    lineTo(20.49f, 19.0f)
                    close()
                    moveTo(9.5f, 14.0f)
                    curveTo(7.01f, 14.0f, 5.0f, 11.99f, 5.0f, 9.5f)
                    reflectiveCurveTo(7.01f, 5.0f, 9.5f, 5.0f)
                    reflectiveCurveTo(14.0f, 7.01f, 14.0f, 9.5f)
                    reflectiveCurveTo(11.99f, 14.0f, 9.5f, 14.0f)
                    close()
                }
            }
            return _search!!
        }
    private var _search: ImageVector? = null
    

    // Replacement for Icons.Default.Close (X)
    val Close: ImageVector
        get() {
            if (_close != null) return _close!!
            _close = materialIcon(name = "Close") {
                materialPath {
                    moveTo(19.0f, 6.41f)
                    lineTo(17.59f, 5.0f)
                    lineTo(12.0f, 10.59f)
                    lineTo(6.41f, 5.0f)
                    lineTo(5.0f, 6.41f)
                    lineTo(10.59f, 12.0f)
                    lineTo(5.0f, 17.59f)
                    lineTo(6.41f, 19.0f)
                    lineTo(12.0f, 13.41f)
                    lineTo(17.59f, 19.0f)
                    lineTo(19.0f, 17.59f)
                    lineTo(13.41f, 12.0f)
                    close()
                }
            }
            return _close!!
        }
    private var _close: ImageVector? = null

    // Replacement for Icons.Default.Edit (Pencil)
    val Edit: ImageVector
        get() {
            if (_edit != null) return _edit!!
            _edit = materialIcon(name = "Edit") {
                 materialPath {
                    moveTo(3.0f, 17.25f)
                    verticalLineTo(21.0f)
                    horizontalLineToRelative(3.75f)
                    lineTo(17.81f, 9.94f)
                    lineToRelative(-3.75f, -3.75f)
                    lineTo(3.0f, 17.25f)
                    close()
                    moveTo(20.71f, 7.04f)
                    curveToRelative(0.39f, -0.39f, 0.39f, -1.02f, 0.0f, -1.41f)
                    lineToRelative(-2.34f, -2.34f)
                    curveToRelative(-0.39f, -0.39f, -1.02f, -0.39f, -1.41f, 0.0f)
                    lineToRelative(-1.83f, 1.83f)
                    lineToRelative(3.75f, 3.75f)
                    lineToRelative(1.83f, -1.83f)
                    close()
                }
            }
            return _edit!!
        }
    private var _edit: ImageVector? = null

    // Replacement for Icons.Default.Delete (Trash2)
    val Delete: ImageVector
        get() {
            if (_delete != null) return _delete!!
            _delete = materialIcon(name = "Delete") {
                materialPath {
                     moveTo(6.0f, 19.0f)
                    curveToRelative(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(8.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    verticalLineTo(7.0f)
                    horizontalLineTo(6.0f)
                    verticalLineToRelative(12.0f)
                    close()
                    moveTo(19.0f, 4.0f)
                    horizontalLineToRelative(-3.5f)
                    lineToRelative(-1.0f, -1.0f)
                    horizontalLineToRelative(-5.0f)
                    lineToRelative(-1.0f, 1.0f)
                    horizontalLineTo(5.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(14.0f)
                    verticalLineTo(4.0f)
                    close()
                }
            }
            return _delete!!
        }
    private var _delete: ImageVector? = null

    // Replacement for Icons.Default.Share
    val Share: ImageVector
        get() {
            if (_share != null) return _share!!
            _share = materialIcon(name = "Share") {
                materialPath {
                    moveTo(18.0f, 16.08f)
                    curveToRelative(-0.76f, 0.0f, -1.44f, 0.3f, -1.96f, 0.77f)
                    lineTo(8.91f, 12.7f)
                    curveToRelative(0.05f, -0.23f, 0.09f, -0.46f, 0.09f, -0.7f)
                    reflectiveCurveToRelative(-0.04f, -0.47f, -0.09f, -0.7f)
                    lineToRelative(7.05f, -4.11f)
                    curveToRelative(0.53f, 0.47f, 1.21f, 0.77f, 1.96f, 0.77f)
                    curveToRelative(1.66f, 0.0f, 3.0f, -1.34f, 3.0f, -3.0f)
                    reflectiveCurveToRelative(-1.34f, -3.0f, -3.0f, -3.0f)
                    reflectiveCurveToRelative(-3.0f, 1.34f, -3.0f, 3.0f)
                    curveToRelative(0.0f, 0.24f, 0.04f, 0.47f, 0.09f, 0.7f)
                    lineTo(8.04f, 9.81f)
                    curveTo(7.5f, 9.31f, 6.79f, 9.0f, 6.0f, 9.0f)
                    curveToRelative(-1.66f, 0.0f, -3.0f, 1.34f, -3.0f, 3.0f)
                    reflectiveCurveToRelative(1.34f, 3.0f, 3.0f, 3.0f)
                    curveToRelative(0.79f, 0.0f, 1.5f, -0.31f, 2.04f, -0.81f)
                    lineToRelative(7.12f, 4.16f)
                    curveToRelative(-0.05f, 0.21f, -0.08f, 0.43f, -0.08f, 0.65f)
                    curveToRelative(0.0f, 1.61f, 1.31f, 2.92f, 2.92f, 2.92f)
                    reflectiveCurveToRelative(2.92f, -1.31f, 2.92f, -2.92f)
                    reflectiveCurveToRelative(-1.31f, -2.92f, -2.92f, -2.92f)
                    close()
                }
            }
            return _share!!
        }
    private var _share: ImageVector? = null

    // Speed (Fast-Forward)
    val Speed: ImageVector
        get() {
            if (_speed != null) return _speed!!
            _speed = materialIcon(name = "Speed") {
                materialPath {
                    // First triangle
                    moveTo(4.0f, 18.0f)
                    lineTo(4.0f, 6.0f)
                    lineTo(12.0f, 12.0f)
                    close()
                    // Second triangle
                    moveTo(12.0f, 18.0f)
                    lineTo(12.0f, 6.0f)
                    lineTo(20.0f, 12.0f)
                    close()
                }
            }
            return _speed!!
        }
    private var _speed: ImageVector? = null

    // Loop (Repeat arrows)
    val Loop: ImageVector
        get() {
             if (_loop != null) return _loop!!
             _loop = materialIcon(name = "Loop") {
                 materialPath {
                    // Top arrow (pointing right)
                    moveTo(7.0f, 7.0f)
                    horizontalLineTo(17.17f)
                    lineTo(14.59f, 4.41f)
                    lineTo(16.0f, 3.0f)
                    lineTo(21.0f, 8.0f)
                    lineTo(16.0f, 13.0f)
                    lineTo(14.59f, 11.59f)
                    lineTo(17.17f, 9.0f)
                    horizontalLineTo(7.0f)
                    curveToRelative(-2.76f, 0.0f, -5.0f, 2.24f, -5.0f, 5.0f)
                    reflectiveCurveToRelative(2.24f, 5.0f, 5.0f, 5.0f)
                    horizontalLineTo(17.0f)
                    verticalLineTo(21.0f)
                    horizontalLineTo(7.0f)
                    curveToRelative(-3.87f, 0.0f, -7.0f, -3.13f, -7.0f, -7.0f)
                    reflectiveCurveToRelative(3.13f, -7.0f, 7.0f, -7.0f)
                    close()
                 }
             }
             return _loop!!
        }
    private var _loop: ImageVector? = null

    // Shadow (Layers)
    val Shadow: ImageVector
        get() {
            if (_shadow != null) return _shadow!!
            _shadow = materialIcon(name = "Shadow") {
                materialPath {
                    moveTo(11.99f, 18.54f)
                    lineToRelative(-7.37f, -5.73f)
                    lineTo(3.0f, 14.07f)
                    lineToRelative(9.0f, 7.0f)
                    lineToRelative(9.0f, -7.0f)
                    lineToRelative(-1.63f, -1.27f)
                    lineToRelative(-7.38f, 5.74f)
                    close()
                    moveTo(12.0f, 16.0f)
                    lineToRelative(7.36f, -5.73f)
                    lineTo(21.0f, 9.0f)
                    lineToRelative(-9.0f, -7.0f)
                    lineToRelative(-9.0f, 7.0f)
                    lineToRelative(1.63f, 1.27f)
                    lineTo(12.0f, 16.0f)
                    close()
                }
            }
            return _shadow!!
        }
    private var _shadow: ImageVector? = null

    // Sleep (Timer/Hourglass-ish)
    val Sleep: ImageVector
        get() {
            if (_sleep != null) return _sleep!!
             _sleep = materialIcon(name = "Sleep") {
                 materialPath {
                    moveTo(11.99f, 2.0f)
                    curveTo(6.47f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f)
                    reflectiveCurveToRelative(4.47f, 10.0f, 9.99f, 10.0f)
                    curveTo(17.52f, 22.0f, 22.0f, 17.52f, 22.0f, 12.0f)
                    reflectiveCurveTo(17.52f, 2.0f, 11.99f, 2.0f)
                    close()
                    moveTo(12.0f, 20.0f)
                    curveToRelative(-4.42f, 0.0f, -8.0f, -3.58f, -8.0f, -8.0f)
                    reflectiveCurveToRelative(3.58f, -8.0f, 8.0f, -8.0f)
                    reflectiveCurveToRelative(8.0f, 3.58f, 8.0f, 8.0f)
                    reflectiveCurveToRelative(-3.58f, 8.0f, -8.0f, 8.0f)
                    close()
                    moveTo(12.5f, 7.0f)
                    horizontalLineTo(11.0f)
                    verticalLineToRelative(6.0f)
                    lineToRelative(5.25f, 3.15f)
                    lineToRelative(0.75f, -1.23f)
                    lineToRelative(-4.5f, -2.67f)
                    verticalLineTo(7.0f)
                    close()
                 }
             }
             return _sleep!!
        }
    private var _sleep: ImageVector? = null

    // Replay (Reset/Restart)
    val Replay: ImageVector
        get() {
            if (_replay != null) return _replay!!
            _replay = materialIcon(name = "Replay") {
                materialPath {
                    moveTo(12.0f, 5.0f)
                    verticalLineTo(1.0f)
                    lineTo(7.0f, 6.0f)
                    lineToRelative(5.0f, 5.0f)
                    verticalLineTo(7.0f)
                    curveToRelative(3.31f, 0.0f, 6.0f, 2.69f, 6.0f, 6.0f)
                    reflectiveCurveToRelative(-2.69f, 6.0f, -6.0f, 6.0f)
                    reflectiveCurveToRelative(-6.0f, -2.69f, -6.0f, -6.0f)
                    horizontalLineTo(4.0f)
                    curveToRelative(0.0f, 4.42f, 3.58f, 8.0f, 8.0f, 8.0f)
                    reflectiveCurveToRelative(8.0f, -3.58f, 8.0f, -8.0f)
                    reflectiveCurveToRelative(-3.58f, -8.0f, -8.0f, -8.0f)
                    close()
                }
            }
            return _replay!!
        }
    private var _replay: ImageVector? = null
    
    // ZoomOutMap (Reset to fit)
    val ZoomOutMap: ImageVector
        get() {
            if (_zoomOutMap != null) return _zoomOutMap!!
            _zoomOutMap = materialIcon(name = "ZoomOutMap") {
                materialPath {
                    moveTo(15.0f, 3.0f)
                    lineToRelative(2.3f, 2.3f)
                    lineToRelative(-2.89f, 2.87f)
                    lineToRelative(1.42f, 1.42f)
                    lineTo(18.7f, 6.7f)
                    lineTo(21.0f, 9.0f)
                    verticalLineTo(3.0f)
                    close()
                    moveTo(3.0f, 9.0f)
                    lineToRelative(2.3f, -2.3f)
                    lineToRelative(2.87f, 2.89f)
                    lineToRelative(1.42f, -1.42f)
                    lineTo(6.7f, 5.3f)
                    lineTo(9.0f, 3.0f)
                    horizontalLineTo(3.0f)
                    close()
                    moveTo(9.0f, 21.0f)
                    lineToRelative(-2.3f, -2.3f)
                    lineToRelative(2.89f, -2.87f)
                    lineToRelative(-1.42f, -1.42f)
                    lineToRelative(-2.87f, 2.89f)
                    lineTo(3.0f, 15.0f)
                    verticalLineToRelative(6.0f)
                    close()
                    moveTo(21.0f, 15.0f)
                    lineToRelative(-2.3f, 2.3f)
                    lineToRelative(-2.87f, -2.89f)
                    lineToRelative(-1.42f, 1.42f)
                    lineToRelative(2.89f, 2.87f)
                    lineTo(15.0f, 21.0f)
                    horizontalLineToRelative(6.0f)
                    close()
                }
            }
            return _zoomOutMap!!
        }
    private var _zoomOutMap: ImageVector? = null

    // Info (Circle with i)
    val Info: ImageVector
        get() {
            if (_info != null) return _info!!
            _info = materialIcon(name = "Info") {
                materialPath {
                    moveTo(12.0f, 2.0f)
                    curveTo(6.48f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f)
                    reflectiveCurveToRelative(4.48f, 10.0f, 10.0f, 10.0f)
                    reflectiveCurveToRelative(10.0f, -4.48f, 10.0f, -10.0f)
                    reflectiveCurveTo(17.52f, 2.0f, 12.0f, 2.0f)
                    close()
                    moveTo(13.0f, 17.0f)
                    horizontalLineToRelative(-2.0f)
                    verticalLineToRelative(-6.0f)
                    horizontalLineToRelative(2.0f)
                    verticalLineToRelative(6.0f)
                    close()
                    moveTo(13.0f, 9.0f)
                    horizontalLineToRelative(-2.0f)
                    verticalLineTo(7.0f)
                    horizontalLineToRelative(2.0f)
                    verticalLineToRelative(2.0f)
                    close()
                }
            }
            return _info!!
        }
    private var _info: ImageVector? = null

    // Stream (Broadcasting/Signal - Sensors style)
    val Stream: ImageVector
        get() {
            if (_stream != null) return _stream!!
            _stream = materialIcon(name = "Stream") {
                materialPath {
                    // Central dot
                    moveTo(12.0f, 15.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    reflectiveCurveToRelative(-0.9f, -2.0f, -2.0f, -2.0f)
                    reflectiveCurveToRelative(-2.0f, 0.9f, -2.0f, 2.0f)
                    reflectiveCurveToRelative(0.9f, 2.0f, 2.0f, 2.0f)
                    close()
                    // Inner ring
                    moveTo(12.0f, 7.0f)
                    curveToRelative(-3.31f, 0.0f, -6.0f, 2.69f, -6.0f, 6.0f)
                    curveToRelative(0.0f, 1.66f, 0.68f, 3.15f, 1.76f, 4.24f)
                    lineToRelative(1.42f, -1.42f)
                    curveTo(8.42f, 15.05f, 8.0f, 14.08f, 8.0f, 13.0f)
                    curveToRelative(0.0f, -2.21f, 1.79f, -4.0f, 4.0f, -4.0f)
                    reflectiveCurveToRelative(4.0f, 1.79f, 4.0f, 4.0f)
                    curveToRelative(0.0f, 1.08f, -0.42f, 2.05f, -1.18f, 2.82f)
                    lineToRelative(1.42f, 1.42f)
                    curveTo(17.32f, 16.15f, 18.0f, 14.66f, 18.0f, 13.0f)
                    curveToRelative(0.0f, -3.31f, -2.69f, -6.0f, -6.0f, -6.0f)
                    close()
                    // Outer ring
                    moveTo(12.0f, 3.0f)
                    curveTo(6.48f, 3.0f, 2.0f, 7.48f, 2.0f, 13.0f)
                    curveToRelative(0.0f, 2.76f, 1.12f, 5.26f, 2.93f, 7.07f)
                    lineToRelative(1.41f, -1.41f)
                    curveTo(4.94f, 17.26f, 4.0f, 15.24f, 4.0f, 13.0f)
                    curveToRelative(0.0f, -4.42f, 3.58f, -8.0f, 8.0f, -8.0f)
                    reflectiveCurveToRelative(8.0f, 3.58f, 8.0f, 8.0f)
                    curveToRelative(0.0f, 2.24f, -0.94f, 4.26f, -2.34f, 5.66f)
                    lineToRelative(1.41f, 1.41f)
                    curveTo(20.88f, 18.26f, 22.0f, 15.76f, 22.0f, 13.0f)
                    curveToRelative(0.0f, -5.52f, -4.48f, -10.0f, -10.0f, -10.0f)
                    close()
                }
            }
            return _stream!!
        }
    private var _stream: ImageVector? = null

    // QueueMusic Icon
    val QueueMusic: ImageVector
        get() {
            if (_queueMusic != null) return _queueMusic!!
            _queueMusic = materialIcon(name = "QueueMusic") {
                materialPath {
                    moveTo(15.0f, 6.0f)
                    horizontalLineTo(3.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(12.0f)
                    verticalLineTo(6.0f)
                    close()
                    moveTo(15.0f, 10.0f)
                    horizontalLineTo(3.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(12.0f)
                    verticalLineTo(10.0f)
                    close()
                    moveTo(3.0f, 16.0f)
                    horizontalLineToRelative(8.0f)
                    verticalLineToRelative(-2.0f)
                    horizontalLineTo(3.0f)
                    verticalLineTo(16.0f)
                    close()
                    moveTo(17.0f, 6.0f)
                    verticalLineToRelative(8.18f)
                    curveToRelative(-0.31f, -0.11f, -0.65f, -0.18f, -1.0f, -0.18f)
                    curveToRelative(-1.66f, 0.0f, -3.0f, 1.34f, -3.0f, 3.0f)
                    reflectiveCurveToRelative(1.34f, 3.0f, 3.0f, 3.0f)
                    reflectiveCurveToRelative(3.0f, -1.34f, 3.0f, -3.0f)
                    verticalLineTo(8.0f)
                    horizontalLineToRelative(3.0f)
                    verticalLineTo(6.0f)
                    horizontalLineTo(17.0f)
                    close()
                }
            }
            return _queueMusic!!
        }
    private var _queueMusic: ImageVector? = null

    // CloudSync (Cloud with sync arrows)
    val CloudSync: ImageVector
        get() {
            if (_cloudSync != null) return _cloudSync!!
            _cloudSync = materialIcon(name = "CloudSync") {
                materialPath {
                    // Cloud shape
                    moveTo(19.35f, 10.04f)
                    curveTo(18.67f, 6.59f, 15.64f, 4.0f, 12.0f, 4.0f)
                    curveToRelative(-2.72f, 0.0f, -5.09f, 1.44f, -6.42f, 3.58f)
                    curveTo(2.37f, 7.93f, 0.0f, 10.55f, 0.0f, 13.7f)
                    curveToRelative(0.0f, 3.36f, 2.73f, 6.09f, 6.1f, 6.09f)
                    horizontalLineTo(19.0f)
                    curveToRelative(2.76f, 0.0f, 5.0f, -2.24f, 5.0f, -5.0f)
                    curveToRelative(0.0f, -2.64f, -2.05f, -4.78f, -4.65f, -4.96f)
                    close()
                    // Small sync arrow
                    moveTo(14.0f, 13.0f)
                    lineToRelative(-4.0f, 0.0f)
                    lineToRelative(0.0f, -2.0f)
                    lineToRelative(4.0f, 0.0f)
                    lineToRelative(0.0f, -2.0f)
                    lineToRelative(3.0f, 3.0f)
                    lineToRelative(-3.0f, 3.0f)
                    close()
                }
            }
            return _cloudSync!!
        }
    private var _cloudSync: ImageVector? = null

    // CloudUpload (Cloud with up arrow)
    val CloudUpload: ImageVector
        get() {
            if (_cloudUpload != null) return _cloudUpload!!
            _cloudUpload = materialIcon(name = "CloudUpload") {
                materialPath {
                    moveTo(19.35f, 10.04f)
                    curveTo(18.67f, 6.59f, 15.64f, 4.0f, 12.0f, 4.0f)
                    curveToRelative(-2.72f, 0.0f, -5.09f, 1.44f, -6.42f, 3.58f)
                    curveTo(2.37f, 7.93f, 0.0f, 10.55f, 0.0f, 13.7f)
                    curveToRelative(0.0f, 3.36f, 2.73f, 6.09f, 6.1f, 6.09f)
                    horizontalLineTo(19.0f)
                    curveToRelative(2.76f, 0.0f, 5.0f, -2.24f, 5.0f, -5.0f)
                    curveToRelative(0.0f, -2.64f, -2.05f, -4.78f, -4.65f, -4.96f)
                    close()
                    // Up arrow
                    moveTo(14.0f, 13.0f)
                    verticalLineToRelative(4.0f)
                    horizontalLineToRelative(-4.0f)
                    verticalLineToRelative(-4.0f)
                    horizontalLineTo(7.0f)
                    lineToRelative(5.0f, -5.0f)
                    lineToRelative(5.0f, 5.0f)
                    horizontalLineTo(14.0f)
                    close()
                }
            }
            return _cloudUpload!!
        }
    private var _cloudUpload: ImageVector? = null

    // CloudDownload (Cloud with down arrow)
    val CloudDownload: ImageVector
        get() {
            if (_cloudDownload != null) return _cloudDownload!!
            _cloudDownload = materialIcon(name = "CloudDownload") {
                materialPath {
                    moveTo(19.35f, 10.04f)
                    curveTo(18.67f, 6.59f, 15.64f, 4.0f, 12.0f, 4.0f)
                    curveToRelative(-2.72f, 0.0f, -5.09f, 1.44f, -6.42f, 3.58f)
                    curveTo(2.37f, 7.93f, 0.0f, 10.55f, 0.0f, 13.7f)
                    curveToRelative(0.0f, 3.36f, 2.73f, 6.09f, 6.1f, 6.09f)
                    horizontalLineTo(19.0f)
                    curveToRelative(2.76f, 0.0f, 5.0f, -2.24f, 5.0f, -5.0f)
                    curveToRelative(0.0f, -2.64f, -2.05f, -4.78f, -4.65f, -4.96f)
                    close()
                    // Down arrow
                    moveTo(17.0f, 13.0f)
                    lineToRelative(-5.0f, 5.0f)
                    lineToRelative(-5.0f, -5.0f)
                    horizontalLineToRelative(3.0f)
                    verticalLineTo(9.0f)
                    horizontalLineToRelative(4.0f)
                    verticalLineToRelative(4.0f)
                    horizontalLineToRelative(3.0f)
                    close()
                }
            }
            return _cloudDownload!!
        }
    private var _cloudDownload: ImageVector? = null

    // DoneAll Icon
    val DoneAll: ImageVector
        get() {
            if (_doneAll != null) return _doneAll!!
            _doneAll = materialIcon(name = "DoneAll") {
                materialPath {
                    moveTo(18.0f, 7.0f)
                    lineToRelative(-1.41f, -1.41f)
                    lineToRelative(-6.34f, 6.34f)
                    lineTo(11.66f, 13.34f)
                    lineTo(18.0f, 7.0f)
                    close()
                    moveTo(22.24f, 7.0f)
                    lineToRelative(-1.41f, -1.41f)
                    lineToRelative(-9.34f, 9.34f)
                    lineToRelative(-4.24f, -4.24f)
                    lineToRelative(-1.41f, 1.41f)
                    lineToRelative(5.66f, 5.66f)
                    lineTo(22.24f, 7.0f)
                    close()
                    moveTo(0.41f, 12.41f)
                    lineTo(6.07f, 18.07f)
                    lineToRelative(1.41f, -1.41f)
                    lineTo(1.83f, 11.0f)
                    lineTo(0.41f, 12.41f)
                    close()
                }
            }
            return _doneAll!!
        }
    private var _doneAll: ImageVector? = null

    // Language icon (Globe)
    val Language: ImageVector
        get() {
            if (_language != null) return _language!!
            _language = materialIcon(name = "Language") {
                materialPath {
                    moveTo(11.99f, 2.0f)
                    curveTo(6.47f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f)
                    reflectiveCurveToRelative(4.47f, 10.0f, 9.99f, 10.0f)
                    curveTo(17.52f, 22.0f, 22.0f, 17.52f, 22.0f, 12.0f)
                    reflectiveCurveTo(17.52f, 2.0f, 11.99f, 2.0f)
                    close()
                    moveTo(18.91f, 8.0f)
                    horizontalLineToRelative(-3.08f)
                    curveToRelative(-0.33f, -1.62f, -0.79f, -3.06f, -1.39f, -4.19f)
                    curveTo(16.36f, 4.65f, 18.06f, 6.08f, 18.91f, 8.0f)
                    close()
                    moveTo(12.0f, 4.04f)
                    curveToRelative(0.73f, 1.24f, 1.25f, 2.59f, 1.51f, 3.96f)
                    horizontalLineToRelative(-3.02f)
                    curveToRelative(0.26f, -1.37f, 0.78f, -2.72f, 1.51f, -3.96f)
                    close()
                    moveTo(4.26f, 14.0f)
                    curveToRelative(-0.16f, -0.64f, -0.26f, -1.31f, -0.26f, -2.0f)
                    reflectiveCurveToRelative(0.1f, -1.36f, 0.26f, -2.0f)
                    horizontalLineToRelative(3.38f)
                    curveToRelative(-0.05f, 0.66f, -0.09f, 1.32f, -0.09f, 2.0f)
                    reflectiveCurveToRelative(0.04f, 1.34f, 0.09f, 2.0f)
                    lineTo(4.26f, 14.0f)
                    close()
                    moveTo(4.26f, 10.0f)
                    horizontalLineToRelative(3.38f)
                    curveToRelative(0.16f, -2.43f, 0.63f, -4.31f, 1.35f, -5.92f)
                    curveTo(6.38f, 5.14f, 4.88f, 7.37f, 4.26f, 10.0f)
                    close()
                    moveTo(12.0f, 19.96f)
                    curveToRelative(-0.73f, -1.24f, -1.25f, -2.59f, -1.51f, -3.96f)
                    horizontalLineToRelative(3.02f)
                    curveToRelative(-0.26f, 1.37f, -0.78f, 2.72f, -1.51f, 3.96f)
                    close()
                    moveTo(14.34f, 14.0f)
                    horizontalLineTo(9.66f)
                    curveToRelative(-0.05f, -0.66f, -0.09f, -1.32f, -0.09f, -2.0f)
                    reflectiveCurveToRelative(0.04f, -1.34f, 0.09f, -2.0f)
                    horizontalLineToRelative(4.68f)
                    curveToRelative(0.05f, 0.66f, 0.09f, 1.32f, 0.09f, 2.0f)
                    reflectiveCurveToRelative(-0.04f, 1.34f, -0.09f, 2.0f)
                    close()
                    moveTo(11.03f, 14.19f)
                    curveToRelative(0.33f, 1.62f, 0.79f, 3.06f, 1.39f, 4.19f)
                    curveToRelative(0.6f, -1.13f, 1.06f, -2.57f, 1.39f, -4.19f)
                    horizontalLineToRelative(-2.78f)
                    close()
                    moveTo(2.0f, 12.0f)
                    curveToRelative(0.0f, 5.52f, 4.48f, 10.0f, 10.0f, 10.0f)
                    reflectiveCurveToRelative(10.0f, -4.48f, 10.0f, -10.0f)
                    reflectiveCurveTo(17.52f, 2.0f, 12.0f, 2.0f)
                    reflectiveCurveTo(2.0f, 6.48f, 2.0f, 12.0f)
                    close()
                }
            }
            return _language!!
        }
    private var _language: ImageVector? = null

    val Palette: ImageVector
        get() {
            if (_palette != null) return _palette!!
            _palette = materialIcon(name = "Palette") {
                materialPath {
                    moveTo(12.0f, 2.0f)
                    curveTo(6.48f, 2.0f, 2.0f, 6.48f, 2.0f, 12.0f)
                    reflectiveCurveToRelative(4.48f, 10.0f, 10.0f, 10.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    curveToRelative(0.0f, -0.49f, -0.18f, -0.96f, -0.51f, -1.34f)
                    curveToRelative(-0.32f, -0.37f, -0.49f, -0.86f, -0.49f, -1.36f)
                    curveToRelative(0.0f, -1.1f, 0.9f, -2.0f, 2.0f, -2.0f)
                    horizontalLineToRelative(2.0f)
                    curveToRelative(2.76f, 0.0f, 5.0f, -2.24f, 5.0f, -5.0f)
                    curveToRelative(0.0f, -5.52f, -4.48f, -10.0f, -10.0f, -10.0f)
                    close()
                    moveTo(6.5f, 12.0f)
                    curveToRelative(-0.83f, 0.0f, -1.5f, -0.67f, -1.5f, -1.5f)
                    reflectiveCurveTo(5.67f, 9.0f, 6.5f, 9.0f)
                    reflectiveCurveTo(8.0f, 9.67f, 8.0f, 10.5f)
                    reflectiveCurveTo(7.33f, 12.0f, 6.5f, 12.0f)
                    close()
                    moveTo(9.5f, 8.0f)
                    curveTo(8.67f, 8.0f, 8.0f, 7.33f, 8.0f, 6.5f)
                    reflectiveCurveTo(8.67f, 5.0f, 9.5f, 5.0f)
                    reflectiveCurveTo(11.0f, 5.67f, 11.0f, 6.5f)
                    reflectiveCurveTo(10.33f, 8.0f, 9.5f, 8.0f)
                    close()
                    moveTo(14.5f, 8.0f)
                    curveToRelative(-0.83f, 0.0f, -1.5f, -0.67f, -1.5f, -1.5f)
                    reflectiveCurveTo(13.67f, 5.0f, 14.5f, 5.0f)
                    reflectiveCurveToRelative(1.5f, 0.67f, 1.5f, 1.5f)
                    reflectiveCurveTo(15.33f, 8.0f, 14.5f, 8.0f)
                    close()
                    moveTo(17.5f, 12.0f)
                    curveToRelative(-0.83f, 0.0f, -1.5f, -0.67f, -1.5f, -1.5f)
                    reflectiveCurveTo(16.67f, 9.0f, 17.5f, 9.0f)
                    reflectiveCurveToRelative(1.5f, 0.67f, 1.5f, 1.5f)
                    reflectiveCurveTo(18.33f, 12.0f, 17.5f, 12.0f)
                    close()
                }
            }
            return _palette!!
        }
    private var _palette: ImageVector? = null

    val Backup: ImageVector
        get() {
            if (_backup != null) return _backup!!
            _backup = materialIcon(name = "Backup") {
                materialPath {
                    moveTo(19.35f, 10.04f)
                    curveTo(18.67f, 6.59f, 15.64f, 4.0f, 12.0f, 4.0f)
                    curveToRelative(-2.72f, 0.0f, -5.09f, 1.44f, -6.42f, 3.58f)
                    curveTo(2.37f, 7.93f, 0.0f, 10.55f, 0.0f, 13.7f)
                    curveToRelative(0.0f, 3.36f, 2.73f, 6.09f, 6.1f, 6.09f)
                    horizontalLineToRelative(12.9f)
                    curveToRelative(2.76f, 0.0f, 5.0f, -2.24f, 5.0f, -5.0f)
                    curveToRelative(0.0f, -2.64f, -2.05f, -4.78f, -4.65f, -4.96f)
                    close()
                    moveTo(14.0f, 13.0f)
                    verticalLineToRelative(4.0f)
                    horizontalLineToRelative(-4.0f)
                    verticalLineToRelative(-4.0f)
                    horizontalLineTo(7.0f)
                    lineToRelative(5.0f, -5.0f)
                    lineToRelative(5.0f, 5.0f)
                    horizontalLineToRelative(-3.0f)
                    close()
                }
            }
            return _backup!!
        }
    private var _backup: ImageVector? = null

    // Sort Icon (List sort)
    val Sort: ImageVector
        get() {
            if (_sort != null) return _sort!!
            _sort = materialIcon(name = "Sort") {
                materialPath {
                    moveTo(3.0f, 18.0f)
                    horizontalLineToRelative(6.0f)
                    verticalLineToRelative(-2.0f)
                    horizontalLineTo(3.0f)
                    verticalLineToRelative(2.0f)
                    close()
                    moveTo(3.0f, 6.0f)
                    verticalLineToRelative(2.0f)
                    horizontalLineToRelative(18.0f)
                    verticalLineTo(6.0f)
                    horizontalLineTo(3.0f)
                    close()
                    moveTo(3.0f, 13.0f)
                    horizontalLineToRelative(12.0f)
                    verticalLineToRelative(-2.0f)
                    horizontalLineTo(3.0f)
                    verticalLineToRelative(2.0f)
                    close()
                }
            }
            return _sort!!
        }
    private var _sort: ImageVector? = null
    
    val Save: ImageVector
        get() {
            if (_save != null) return _save!!
            _save = materialIcon(name = "Save") {
                materialPath {
                    moveTo(17.0f, 3.0f)
                    horizontalLineTo(5.0f)
                    curveToRelative(-1.11f, 0.0f, -2.0f, 0.9f, -2.0f, 2.0f)
                    verticalLineToRelative(14.0f)
                    curveToRelative(0.0f, 1.1f, 0.89f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(14.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    verticalLineTo(7.0f)
                    lineToRelative(-4.0f, -4.0f)
                    close()
                    moveTo(12.0f, 19.0f)
                    curveToRelative(-1.66f, 0.0f, -3.0f, -1.34f, -3.0f, -3.0f)
                    reflectiveCurveToRelative(1.34f, -3.0f, 3.0f, -3.0f)
                    reflectiveCurveToRelative(3.0f, 1.34f, 3.0f, 3.0f)
                    reflectiveCurveToRelative(-1.34f, 3.0f, -3.0f, 3.0f)
                    close()
                    moveTo(15.0f, 9.0f)
                    horizontalLineTo(5.0f)
                    verticalLineTo(5.0f)
                    horizontalLineToRelative(10.0f)
                    verticalLineToRelative(4.0f)
                    close()
                }
            }
            return _save!!
        }
    private var _save: ImageVector? = null

    val Folder: ImageVector
        get() {
            if (_folder != null) return _folder!!
            _folder = materialIcon(name = "Folder") {
                materialPath {
                    moveTo(10.0f, 4.0f)
                    horizontalLineTo(4.0f)
                    curveToRelative(-1.1f, 0.0f, -1.99f, 0.9f, -1.99f, 2.0f)
                    lineTo(2.0f, 18.0f)
                    curveToRelative(0.0f, 1.1f, 0.9f, 2.0f, 2.0f, 2.0f)
                    horizontalLineToRelative(16.0f)
                    curveToRelative(1.1f, 0.0f, 2.0f, -0.9f, 2.0f, -2.0f)
                    verticalLineTo(8.0f)
                    curveToRelative(0.0f, -1.1f, -0.9f, -2.0f, -2.0f, -2.0f)
                    horizontalLineToRelative(-8.0f)
                    lineToRelative(-2.0f, -2.0f)
                    close()
                }
            }
            return _folder!!
        }
    private var _folder: ImageVector? = null

    val Done: ImageVector
        get() = Check

    val ChevronLeft: ImageVector
        get() {
            if (_chevronLeft != null) return _chevronLeft!!
            _chevronLeft = materialIcon(name = "ChevronLeft") {
                materialPath {
                    moveTo(15.41f, 7.41f)
                    lineTo(14.0f, 6.0f)
                    lineToRelative(-6.0f, 6.0f)
                    lineToRelative(6.0f, 6.0f)
                    lineToRelative(1.41f, -1.41f)
                    lineTo(10.83f, 12.0f)
                    close()
                }
            }
            return _chevronLeft!!
        }
    private var _chevronLeft: ImageVector? = null

    val ChevronRight: ImageVector
        get() {
            if (_chevronRight != null) return _chevronRight!!
            _chevronRight = materialIcon(name = "ChevronRight") {
                materialPath {
                    moveTo(10.0f, 6.0f)
                    lineTo(8.59f, 7.41f)
                    lineTo(13.17f, 12.0f)
                    lineToRelative(-4.58f, 4.59f)
                    lineTo(10.0f, 18.0f)
                    lineToRelative(6.0f, -6.0f)
                    close()
                }
            }
            return _chevronRight!!
        }
    private var _chevronRight: ImageVector? = null
}


